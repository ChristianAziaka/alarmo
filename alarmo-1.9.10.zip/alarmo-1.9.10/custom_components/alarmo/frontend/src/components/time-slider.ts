import { LitElement, html, css } from 'lit';
import { property, customElement } from 'lit/decorators.js';
import { localize } from '../../localize/localize';
import { HomeAssistant } from '../types';

@customElement('time-slider')
export class TimeSlider extends LitElement {
  hass?: HomeAssistant;

  @property({ type: Number })
  min = 0;

  @property({ type: Number })
  max = 100;

  @property({ type: Number })
  step = 5;

  @property({ type: Number })
  value = 0;

  @property() scaleFactor = 1;

  @property({ type: String })
  unit = '';

  @property({ type: Boolean })
  disabled = false;

  @property({ type: String })
  zeroValue?: string;

  firstUpdated() {
    if (this.value > 0 && this.value < 60) this.unit = 'sec';
    if (this.unit == 'min') this.scaleFactor = 1 / 60;
    if (this.unit == 'min') this.step = 1;
  }

  render() {
    return html`
      <div class="container">
        <div class="prefix">
          <slot name="prefix"></slot>
        </div>
        <div class="slider">
          ${this.getSlider()}
        </div>
        <div class="value${this.disabled ? ' disabled' : ''}" @click=${this.toggleUnit}>
          ${this.getValue()}
        </div>
      </div>
    `;
  }

  getValue() {
    const value = Number(Math.round(this.value * this.scaleFactor));
    if (!value && this.zeroValue) {
      return this.zeroValue;
    }
    return `${value} ${this.getUnit()}`;
  }

  getUnit() {
    switch (this.unit) {
      case 'sec':
        return localize('components.time_slider.seconds', this.hass!.language);
      case 'min':
        return localize('components.time_slider.minutes', this.hass!.language);
      default:
        return '';
    }
  }

  getSlider() {
    return html`
      <ha-slider
        pin
        min=${Math.round(this.min * this.scaleFactor)}
        max=${Math.round(this.max * this.scaleFactor)}
        step=${this.step}
        value=${Math.round(this.value * this.scaleFactor)}
        ?disabled=${this.disabled}
        @change=${this.updateValue}
      ></ha-slider>
    `;
  }

  updateValue(e: Event) {
    const value = Number((e.target as HTMLInputElement).value);
    this.value = Math.round(value / this.scaleFactor);
  }

  toggleUnit() {
    this.unit = this.unit == 'min' ? 'sec' : 'min';
    this.scaleFactor = this.unit == 'min' ? 1 / 60 : 1;
    this.step = this.unit == 'min' ? 1 : 5;
  }

  static styles = css`
    :host {
      display: flex;
      flex-direction: column;
      min-width: 250px;
    }

    div.container {
      display: grid;
      grid-template-columns: max-content 1fr 60px;
      grid-template-rows: min-content;
      grid-template-areas: 'prefix slider value';
    }

    div.prefix {
      grid-area: prefix;
      display: flex;
      align-items: center;
    }

    div.slider {
      grid-area: slider;
      display: flex;
      align-items: center;
      flex: 1;
    }

    div.value {
      grid-area: value;
      min-width: 40px;
      display: flex;
      align-items: center;
      justify-content: flex-end;
      cursor: pointer;
    }

    ha-slider {
      width: 100%;
    }

    .disabled {
      color: var(--disabled-text-color);
    }
  `;
}
